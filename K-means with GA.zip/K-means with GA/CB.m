function x=CB(x,lb,ub)

     x=max(x,lb);
     x=min(x,ub);


end