function  mutpop=mutation(mutpop,pop,data)

nmut=data.nmut;
npop=data.npop;


for n=1:nmut
    
    i1=randi([1 npop]);
    mutpop(n).x=UniformMutation(pop(i1).x,0.01,data.lb,data.ub);
    mutpop(n)=fitness(mutpop(n),data);
    
end


end





function y=UniformMutation(x,R,lb,ub)

n=numel(x);
I=randsample(n,ceil(R*n));
d=unifrnd(-0.1,0.1,size(lb)).*(ub-lb);
x(I)=x(I)+d(I);
y=x;
end


