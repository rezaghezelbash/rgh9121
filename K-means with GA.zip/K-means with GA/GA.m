%% K-means Clustering with Genetic Algorithm
%%
clc
clear
close all
format shortG
%% Insert Data

M=xlsread('D:\Matlab code\K-means with GA\input data.xlsx',1);
A=input('Number of Cluster:    ');
B=input('number of population:    '); 
C=input('Maximum iter:    ');

NC=A;%Number of Cluster

[nd,ni]=size(M);             
% ni = Number of Inputs
% nd = Number of Data
 
UB=repmat(max(M),NC,1);
LB=repmat(min(M),NC,1);

nvar=NC*ni;

save data
data=load('data.mat');

lb=0*ones(1,nvar);
ub=1*ones(1,nvar);


%% parametres setting


npop=B;     % number of population

pc=0.7;       % percent of crossover
ncross=2*round(npop*pc/2);  % number of crossover offspring

pm=1-pc;        %  percent of mutation
nmut=round(npop*pm);  % number of mutation offspring
maxiter=C;
data.npop=npop;
data.ncross=ncross;
data.nmut=nmut;
data.maxiter=maxiter;
data.lb=lb;
data.ub=ub;

%% initialization
tic
emp.x=[];
emp.fit=[];
emp.info=[];
emp.SCH=[];
pop=repmat(emp,npop,1);

for i=1:npop
   
    pop(i).x=unifrnd(lb,ub);
    pop(i)=fitness(pop(i),data);
    
end

%% main loop
BEST=zeros(maxiter,1);
MEAN=zeros(maxiter,1);

for iter=1:maxiter
    
    % crossover
    crosspop=repmat(emp,ncross,1);
    crosspop=crossover(crosspop,pop,data);
    
    % mutation
    mutpop=repmat(emp,nmut,1);
    mutpop=mutation(mutpop,pop,data);
    
    
    % Merged
    [pop]=[pop;crosspop;mutpop];
    
    
   

    % Sorting
    [value,index]=sort([pop.fit]);
    pop=pop(index);
    gpop=pop(1);
    
    % Select
    pop=pop(1:npop);
    

    
    BEST(iter)=gpop.fit;
    MEAN(iter)=mean([pop.fit]);
    
    disp([' Iter = ' num2str(iter)  ' BEST = ' num2str(BEST(iter))])
    

    
    
end

%% results

disp([ ' Best Fitness = '  num2str(gpop.fit)])
disp([ ' Time = '  num2str(toc)])

figure(1)
semilogy(BEST,'r')
%hold on
%semilogy(MEAN,'b')
xlabel('Iteration')
ylabel('Fitness')
legend('BEST','MEAN')
title('GA')

sol=gpop;
OUT(:,1)=1:nd;
OUT(:,2)=sol.info.dis';
OUT(:,3)=sol.info.clu';
disp('================================================')
disp('          data      dis              clu')
disp('================================================')
%disp(OUT);
%disp(' ');
%disp('Center');
%disp(sol.info.center);
%% Concolusion
Final= OUT(:,3);
%%
disp('++++++++++++++++++++');
disp('finished');

%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Reza Ghezelbash                                    %
%         Amirkabir University of Technology                 %
%              Rezaghezelbash@aut.ac.ir                      %  
%        K-means Clustering with Genetic Algorithm           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%