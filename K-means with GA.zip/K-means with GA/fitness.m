function sol=fitness(sol,data)

load data
sol.x=CB(sol.x,0,1);

x=sol.x;

x=reshape(x,NC,ni);
x=x.*(UB-LB);
center=x+LB;


tdis=pdist2(center,M);
[dis,clu]=min(tdis);
    
sol.fit=mean(dis);
sol.info.dis=dis;
sol.info.clu=clu;
sol.info.center=center;





end